﻿namespace odaurehonbe.Models
{
    public class UpdateTicketRequest
    {
        public int ClerkID { get; set; }
        public int NewSeatID { get; set; }
        public int NotificationID { get; set; }
    }
}

